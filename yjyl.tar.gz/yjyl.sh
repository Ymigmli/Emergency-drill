#/bin/bash

start_time=`date '+%Y%m%d-%H%M%S'`
start_pwd=`pwd`

if [ "`ls -A /var/www/html/`" = "" ] ; then
    tar zxf html.tar.gz -C /var/www/html/
    if [ $? -eq 0 ] ; then
        echo "01.解压成功：抵抗敏感词/敏感图片攻击环境至/var/www/html"
    else
        echo "01.解压失败：抵抗敏感词/敏感图片攻击环境至/var/www/html"
    fi
else
    tar zcPf $start_pwd/html-$start_time.tar.gz /var/www/html/
        if [ $? -eq 0 ] ; then
            echo "01.备份成功：备份/var/www/html/至$start_pwd/html-$start_time.tar.gz"
            tar zxf html.tar.gz -C /var/www/html
                if [ $? -eq 0 ] ; then
                    echo "01.解压成功：抵抗敏感词/敏感图片攻击环境至/var/www/html"
                else
                    echo "01.解压失败：抵抗敏感词/敏感图片攻击环境至/var/www/html"
                fi
        else
            echo "01.备份失败：备份/var/www/html至$start_pwd/html-$start_time.tar.gz"
        fi
fi


if [ ! -d /tmp/xmr ] ; then
    mkdir /tmp/xmr
    if [ $? -eq 0 ] ; then
        echo "02.创建成功：目录/tmp/xmr"
        tar zxf xmr.tar.gz -C /tmp/xmr
            if [ $? -eq 0 ] ; then
                echo "02.解压成功：抵抗操作系统恶意程序攻击环境至/tmp/xmr"
            else
                echo "02.解压失败：抵抗操作系统恶意程序攻击环境至/tmp/xmr"
            fi
    else
        echo "02.创建失败：目录/tmp/xmr/"
    fi
else
    tar zcPf $start_pwd/xmr-$start_time.tar.gz /tmp/xmr/
    if [ $? -eq 0 ] ; then
        echo "02.备份成功：备份/tmp/xmr至$start_pwd/xmr-$start_time.tar.gz"
        tar zxf xmr.tar.gz -C /tmp/xmr/
        if [ $? -eq 0 ] ; then
            echo "02.解压成功：抵抗操作系统恶意程序攻击环境至/tmp/xmr"
        else
            echo "02.解压失败：抵抗操作系统恶意程序攻击环境至/tmp/xmr"
        fi
    else
        echo "02.备份失败：备份/tmp/xmr至$start_pwd/xmr-$start_time.tar.gz"
    fi
fi
